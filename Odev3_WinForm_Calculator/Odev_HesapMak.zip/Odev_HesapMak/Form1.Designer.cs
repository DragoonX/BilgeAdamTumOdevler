﻿namespace Odev_HesapMak
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbox_main = new System.Windows.Forms.TextBox();
            this.btn_zero = new System.Windows.Forms.Button();
            this.btn_comma = new System.Windows.Forms.Button();
            this.btn_one = new System.Windows.Forms.Button();
            this.btn_two = new System.Windows.Forms.Button();
            this.btn_three = new System.Windows.Forms.Button();
            this.btn_four = new System.Windows.Forms.Button();
            this.btn_five = new System.Windows.Forms.Button();
            this.btn_six = new System.Windows.Forms.Button();
            this.btn_nine = new System.Windows.Forms.Button();
            this.btn_eight = new System.Windows.Forms.Button();
            this.btn_seven = new System.Windows.Forms.Button();
            this.btn_equal = new System.Windows.Forms.Button();
            this.btn_plus = new System.Windows.Forms.Button();
            this.btn_divide = new System.Windows.Forms.Button();
            this.btn_times = new System.Windows.Forms.Button();
            this.btn_minus = new System.Windows.Forms.Button();
            this.btn_power = new System.Windows.Forms.Button();
            this.btn_c = new System.Windows.Forms.Button();
            this.btn_del = new System.Windows.Forms.Button();
            this.btn_percent = new System.Windows.Forms.Button();
            this.lbl_details = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tbox_main
            // 
            this.tbox_main.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbox_main.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbox_main.Location = new System.Drawing.Point(14, 37);
            this.tbox_main.MaximumSize = new System.Drawing.Size(260, 50);
            this.tbox_main.MaxLength = 0;
            this.tbox_main.Name = "tbox_main";
            this.tbox_main.Size = new System.Drawing.Size(258, 45);
            this.tbox_main.TabIndex = 0;
            this.tbox_main.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btn_zero
            // 
            this.btn_zero.Location = new System.Drawing.Point(14, 353);
            this.btn_zero.Name = "btn_zero";
            this.btn_zero.Size = new System.Drawing.Size(60, 60);
            this.btn_zero.TabIndex = 1;
            this.btn_zero.Text = "0";
            this.btn_zero.UseVisualStyleBackColor = true;
            this.btn_zero.Click += new System.EventHandler(this.Btn_zero_Click);
            // 
            // btn_comma
            // 
            this.btn_comma.Location = new System.Drawing.Point(80, 353);
            this.btn_comma.Name = "btn_comma";
            this.btn_comma.Size = new System.Drawing.Size(60, 60);
            this.btn_comma.TabIndex = 2;
            this.btn_comma.Text = ",";
            this.btn_comma.UseVisualStyleBackColor = true;
            this.btn_comma.Click += new System.EventHandler(this.Btn_comma_Click);
            // 
            // btn_one
            // 
            this.btn_one.Location = new System.Drawing.Point(14, 287);
            this.btn_one.Name = "btn_one";
            this.btn_one.Size = new System.Drawing.Size(60, 60);
            this.btn_one.TabIndex = 4;
            this.btn_one.Text = "1";
            this.btn_one.UseVisualStyleBackColor = true;
            this.btn_one.Click += new System.EventHandler(this.Btn_one_Click);
            // 
            // btn_two
            // 
            this.btn_two.Location = new System.Drawing.Point(80, 287);
            this.btn_two.Name = "btn_two";
            this.btn_two.Size = new System.Drawing.Size(60, 60);
            this.btn_two.TabIndex = 5;
            this.btn_two.Text = "2";
            this.btn_two.UseVisualStyleBackColor = true;
            this.btn_two.Click += new System.EventHandler(this.Btn_two_Click);
            // 
            // btn_three
            // 
            this.btn_three.Location = new System.Drawing.Point(146, 287);
            this.btn_three.Name = "btn_three";
            this.btn_three.Size = new System.Drawing.Size(60, 60);
            this.btn_three.TabIndex = 6;
            this.btn_three.Text = "3";
            this.btn_three.UseVisualStyleBackColor = true;
            this.btn_three.Click += new System.EventHandler(this.Btn_three_Click);
            // 
            // btn_four
            // 
            this.btn_four.Location = new System.Drawing.Point(14, 221);
            this.btn_four.Name = "btn_four";
            this.btn_four.Size = new System.Drawing.Size(60, 60);
            this.btn_four.TabIndex = 7;
            this.btn_four.Text = "4";
            this.btn_four.UseVisualStyleBackColor = true;
            this.btn_four.Click += new System.EventHandler(this.Btn_four_Click);
            // 
            // btn_five
            // 
            this.btn_five.Location = new System.Drawing.Point(80, 221);
            this.btn_five.Name = "btn_five";
            this.btn_five.Size = new System.Drawing.Size(60, 60);
            this.btn_five.TabIndex = 8;
            this.btn_five.Text = "5";
            this.btn_five.UseVisualStyleBackColor = true;
            this.btn_five.Click += new System.EventHandler(this.Btn_five_Click);
            // 
            // btn_six
            // 
            this.btn_six.Location = new System.Drawing.Point(146, 221);
            this.btn_six.Name = "btn_six";
            this.btn_six.Size = new System.Drawing.Size(60, 60);
            this.btn_six.TabIndex = 9;
            this.btn_six.Text = "6";
            this.btn_six.UseVisualStyleBackColor = true;
            this.btn_six.Click += new System.EventHandler(this.Btn_six_Click);
            // 
            // btn_nine
            // 
            this.btn_nine.Location = new System.Drawing.Point(146, 155);
            this.btn_nine.Name = "btn_nine";
            this.btn_nine.Size = new System.Drawing.Size(60, 60);
            this.btn_nine.TabIndex = 12;
            this.btn_nine.Text = "9";
            this.btn_nine.UseVisualStyleBackColor = true;
            this.btn_nine.Click += new System.EventHandler(this.Btn_nine_Click);
            // 
            // btn_eight
            // 
            this.btn_eight.Location = new System.Drawing.Point(80, 155);
            this.btn_eight.Name = "btn_eight";
            this.btn_eight.Size = new System.Drawing.Size(60, 60);
            this.btn_eight.TabIndex = 11;
            this.btn_eight.Text = "8";
            this.btn_eight.UseVisualStyleBackColor = true;
            this.btn_eight.Click += new System.EventHandler(this.Btn_eight_Click);
            // 
            // btn_seven
            // 
            this.btn_seven.Location = new System.Drawing.Point(14, 155);
            this.btn_seven.Name = "btn_seven";
            this.btn_seven.Size = new System.Drawing.Size(60, 60);
            this.btn_seven.TabIndex = 10;
            this.btn_seven.Text = "7";
            this.btn_seven.UseVisualStyleBackColor = true;
            this.btn_seven.Click += new System.EventHandler(this.Btn_seven_Click);
            // 
            // btn_equal
            // 
            this.btn_equal.Location = new System.Drawing.Point(146, 353);
            this.btn_equal.Name = "btn_equal";
            this.btn_equal.Size = new System.Drawing.Size(60, 60);
            this.btn_equal.TabIndex = 13;
            this.btn_equal.Text = "=";
            this.btn_equal.UseVisualStyleBackColor = true;
            this.btn_equal.Click += new System.EventHandler(this.Btn_equal_Click);
            // 
            // btn_plus
            // 
            this.btn_plus.Location = new System.Drawing.Point(212, 353);
            this.btn_plus.Name = "btn_plus";
            this.btn_plus.Size = new System.Drawing.Size(60, 60);
            this.btn_plus.TabIndex = 17;
            this.btn_plus.Text = "+";
            this.btn_plus.UseVisualStyleBackColor = true;
            this.btn_plus.Click += new System.EventHandler(this.Btn_plus_Click);
            // 
            // btn_divide
            // 
            this.btn_divide.Location = new System.Drawing.Point(212, 155);
            this.btn_divide.Name = "btn_divide";
            this.btn_divide.Size = new System.Drawing.Size(60, 60);
            this.btn_divide.TabIndex = 16;
            this.btn_divide.Text = "/";
            this.btn_divide.UseVisualStyleBackColor = true;
            this.btn_divide.Click += new System.EventHandler(this.Btn_divide_Click);
            // 
            // btn_times
            // 
            this.btn_times.Location = new System.Drawing.Point(212, 221);
            this.btn_times.Name = "btn_times";
            this.btn_times.Size = new System.Drawing.Size(60, 60);
            this.btn_times.TabIndex = 15;
            this.btn_times.Text = "*";
            this.btn_times.UseVisualStyleBackColor = true;
            this.btn_times.Click += new System.EventHandler(this.Btn_times_Click);
            // 
            // btn_minus
            // 
            this.btn_minus.Location = new System.Drawing.Point(212, 287);
            this.btn_minus.Name = "btn_minus";
            this.btn_minus.Size = new System.Drawing.Size(60, 60);
            this.btn_minus.TabIndex = 14;
            this.btn_minus.Text = "-";
            this.btn_minus.UseVisualStyleBackColor = true;
            this.btn_minus.Click += new System.EventHandler(this.Btn_minus_Click);
            // 
            // btn_power
            // 
            this.btn_power.Location = new System.Drawing.Point(146, 89);
            this.btn_power.Name = "btn_power";
            this.btn_power.Size = new System.Drawing.Size(60, 60);
            this.btn_power.TabIndex = 21;
            this.btn_power.Text = "^";
            this.btn_power.UseVisualStyleBackColor = true;
            this.btn_power.Click += new System.EventHandler(this.Btn_power_Click);
            // 
            // btn_c
            // 
            this.btn_c.Location = new System.Drawing.Point(80, 89);
            this.btn_c.Name = "btn_c";
            this.btn_c.Size = new System.Drawing.Size(60, 60);
            this.btn_c.TabIndex = 20;
            this.btn_c.Text = "C";
            this.btn_c.UseVisualStyleBackColor = true;
            this.btn_c.Click += new System.EventHandler(this.Btn_c_Click);
            // 
            // btn_del
            // 
            this.btn_del.Location = new System.Drawing.Point(14, 89);
            this.btn_del.Name = "btn_del";
            this.btn_del.Size = new System.Drawing.Size(60, 60);
            this.btn_del.TabIndex = 19;
            this.btn_del.Text = "DEL";
            this.btn_del.UseVisualStyleBackColor = true;
            this.btn_del.Click += new System.EventHandler(this.Btn_ac_Click);
            // 
            // btn_percent
            // 
            this.btn_percent.Location = new System.Drawing.Point(212, 89);
            this.btn_percent.Name = "btn_percent";
            this.btn_percent.Size = new System.Drawing.Size(60, 60);
            this.btn_percent.TabIndex = 18;
            this.btn_percent.Text = "Mod";
            this.btn_percent.UseVisualStyleBackColor = true;
            this.btn_percent.Click += new System.EventHandler(this.Btn_percent_Click);
            // 
            // lbl_details
            // 
            this.lbl_details.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_details.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_details.Location = new System.Drawing.Point(14, 9);
            this.lbl_details.Name = "lbl_details";
            this.lbl_details.Size = new System.Drawing.Size(258, 25);
            this.lbl_details.TabIndex = 22;
            this.lbl_details.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 428);
            this.Controls.Add(this.lbl_details);
            this.Controls.Add(this.btn_power);
            this.Controls.Add(this.btn_c);
            this.Controls.Add(this.btn_del);
            this.Controls.Add(this.btn_percent);
            this.Controls.Add(this.btn_plus);
            this.Controls.Add(this.btn_divide);
            this.Controls.Add(this.btn_times);
            this.Controls.Add(this.btn_minus);
            this.Controls.Add(this.btn_equal);
            this.Controls.Add(this.btn_nine);
            this.Controls.Add(this.btn_eight);
            this.Controls.Add(this.btn_seven);
            this.Controls.Add(this.btn_six);
            this.Controls.Add(this.btn_five);
            this.Controls.Add(this.btn_four);
            this.Controls.Add(this.btn_three);
            this.Controls.Add(this.btn_two);
            this.Controls.Add(this.btn_one);
            this.Controls.Add(this.btn_comma);
            this.Controls.Add(this.btn_zero);
            this.Controls.Add(this.tbox_main);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Mini Hesap Makinesi";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbox_main;
        private System.Windows.Forms.Button btn_zero;
        private System.Windows.Forms.Button btn_comma;
        private System.Windows.Forms.Button btn_one;
        private System.Windows.Forms.Button btn_two;
        private System.Windows.Forms.Button btn_three;
        private System.Windows.Forms.Button btn_four;
        private System.Windows.Forms.Button btn_five;
        private System.Windows.Forms.Button btn_six;
        private System.Windows.Forms.Button btn_nine;
        private System.Windows.Forms.Button btn_eight;
        private System.Windows.Forms.Button btn_seven;
        private System.Windows.Forms.Button btn_equal;
        private System.Windows.Forms.Button btn_plus;
        private System.Windows.Forms.Button btn_divide;
        private System.Windows.Forms.Button btn_times;
        private System.Windows.Forms.Button btn_minus;
        private System.Windows.Forms.Button btn_power;
        private System.Windows.Forms.Button btn_c;
        private System.Windows.Forms.Button btn_del;
        private System.Windows.Forms.Button btn_percent;
        private System.Windows.Forms.Label lbl_details;
    }
}

