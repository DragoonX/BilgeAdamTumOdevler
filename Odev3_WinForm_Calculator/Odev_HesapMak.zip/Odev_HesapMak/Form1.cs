﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Odev_HesapMak
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public double ilksayi = 0.0;
        public string op;

        public void buttonFunctions(string buttonvalue)
        {
            if (tbox_main.Text == "0" || tbox_main.Text == null || tbox_main.Text == "NaN")
                tbox_main.Clear();
            tbox_main.Text += buttonvalue;
        }

        public void operatorButtonFunctions(string operat)
        {
            ilksayi = Convert.ToDouble(tbox_main.Text);
            op = operat;
            lbl_details.Text = tbox_main.Text + " " + op;
            tbox_main.Text = "0";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tbox_main.Clear(); //form yüklendiğinde textbox silinir.
            tbox_main.AppendText("0"); //textbox'a sıfır yazılır.
        }

        private void Btn_one_Click(object sender, EventArgs e)
        {
            buttonFunctions("1");
        }

        private void Btn_zero_Click(object sender, EventArgs e)
        {
            if (tbox_main.Text == "0") tbox_main.Text = "0";
            else  tbox_main.Text += "0";
        }

        private void Btn_two_Click(object sender, EventArgs e)
        {
            buttonFunctions("2");
        }

        private void Btn_three_Click(object sender, EventArgs e)
        {
            buttonFunctions("3");
        }

        private void Btn_four_Click(object sender, EventArgs e)
        {
            buttonFunctions("4");
        }

        private void Btn_five_Click(object sender, EventArgs e)
        {
            buttonFunctions("5");
        }

        private void Btn_six_Click(object sender, EventArgs e)
        {
            buttonFunctions("6");
        }

        private void Btn_seven_Click(object sender, EventArgs e)
        {
            buttonFunctions("7");
        }

        private void Btn_eight_Click(object sender, EventArgs e)
        {
            buttonFunctions("8");
        }

        private void Btn_nine_Click(object sender, EventArgs e)
        {
            buttonFunctions("9");
        }

        private void Btn_ac_Click(object sender, EventArgs e)
        {
            tbox_main.Text = tbox_main.Text.Remove(tbox_main.Text.Length - 1, 1);

            if(tbox_main.Text == "" || tbox_main.Text=="NaN")
            {
                tbox_main.Text = "0";
            }
        }

        private void Btn_c_Click(object sender, EventArgs e)
        {
            tbox_main.Clear();
            tbox_main.Text = "0";
            lbl_details.Text = null;
        }

        private void Btn_power_Click(object sender, EventArgs e)
        {
            operatorButtonFunctions("^");
        }

        private void Btn_comma_Click(object sender, EventArgs e)
        {
            if(!tbox_main.Text.Contains(","))
            {
                tbox_main.Text += ",";
            }
        }

        private void Btn_plus_Click(object sender, EventArgs e)
        {
            operatorButtonFunctions("+");
        }

        private void Btn_equal_Click(object sender, EventArgs e)
        {
            double ikincisayi;
            double sonuc;

            ikincisayi = Convert.ToDouble(tbox_main.Text);

            switch (op)
            {
                case "+":
                    sonuc = ilksayi + ikincisayi;
                    tbox_main.Text = Convert.ToString(sonuc);
                    sonuc = ilksayi;
                    lbl_details.Text = "";
                    break;
                case "-":
                    sonuc = ilksayi - ikincisayi;
                    tbox_main.Text = Convert.ToString(sonuc);
                    sonuc = ilksayi;
                    lbl_details.Text = "";
                    break;
                case "*":
                    sonuc = ilksayi * ikincisayi;
                    tbox_main.Text = Convert.ToString(sonuc);
                    sonuc = ilksayi;
                    lbl_details.Text = "";
                    break;
                case "/":
                    sonuc = ilksayi / ikincisayi;
                    tbox_main.Text = Convert.ToString(sonuc);
                    sonuc = ilksayi;
                    lbl_details.Text = "";
                    break;
                case "^":
                    sonuc = Math.Pow(ilksayi,ikincisayi);
                    tbox_main.Text = Convert.ToString(sonuc);
                    sonuc = ilksayi;
                    lbl_details.Text = "";
                    break;
                case "mod":
                    sonuc = ilksayi % ikincisayi;
                    tbox_main.Text = Convert.ToString(sonuc);
                    sonuc = ilksayi;
                    lbl_details.Text = "";
                    break;
                default:
                    break;
            }
        }

        private void Btn_minus_Click(object sender, EventArgs e)
        {
            operatorButtonFunctions("-");
        }

        private void Btn_times_Click(object sender, EventArgs e)
        {
            operatorButtonFunctions("*");
        }

        private void Btn_divide_Click(object sender, EventArgs e)
        {
            operatorButtonFunctions("/");
        }

        private void Btn_percent_Click(object sender, EventArgs e)
        {
            operatorButtonFunctions("mod");
        }
    }
}
