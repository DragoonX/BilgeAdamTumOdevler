CREATE PROCEDURE PROSEDUR_EKLE AS EXEC('
	CREATE VIEW GaleriView2 AS 
	SELECT Resimler.ResimKategoriId,Resimler.ResimYukleyenId FROM Resimler 
		INNER JOIN Kategoriler ON Resimler.ResimKategoriId = Kategoriler.KategoriId
		INNER JOIN Kullanicilar ON Resimler.ResimYukleyenId = Kullanicilar.KullaniciId
')